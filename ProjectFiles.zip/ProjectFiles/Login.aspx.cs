﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.ServiceModel.Channels;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)

    {
        //  var ID, password;
        var ID = idT.Text;
        var password=PassT.Text;
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        if(DropDownList1.SelectedValue=="ADMIN")
        {
           string query="Select * from Admin where Admin_id=" + ID + "and Admin_pass = dbo.EncryptPassword('" + password + "');";
            SqlCommand cmd=new SqlCommand(query, conn);
            SqlDataReader res = cmd.ExecuteReader();
            if(res.HasRows)
            {
                Session["Admin_ID"] = ID;
                Response.Redirect("AdminHome.aspx");
            }
            else
            {
                Response.Write("<script>alert('Admin Does not Exist');</script>");

              //  Response.Redirect("Login.aspx");
            }
        }
        else if(DropDownList1.SelectedValue == "FACULTY")
        {
            string query2 = "Select * from Faculty where Fac_id=" + ID + "and Fac_pass = dbo.EncryptPassword('" + password + "');";
            SqlCommand cmd2= new SqlCommand(query2, conn);
            SqlDataReader res = cmd2.ExecuteReader();
            if (res.HasRows)
            {
                Session["Faculty_ID"] = ID;
                Response.Redirect("FacultyHome.aspx");
            }
            else
            {
                Response.Write("<script>alert('Faculty Does not Exist ');</script>");

           //     Response.Redirect("Login.aspx");
            }
        }
        else if (DropDownList1.SelectedValue == "STUDENT ASSISTANT")
        {
            string query3 = "Select * from Applicants where Appl_id=" + ID + "and Appl_pass = dbo.EncryptPassword('" + password + "') and Appl_hire_status = "+1+";";
            SqlCommand cmd3 = new SqlCommand(query3, conn);
            SqlDataReader res = cmd3.ExecuteReader();
            if (res.HasRows)
            {
                Session["APPLICANT_ID"]=ID;
                Response.Redirect("ApplicantHome.aspx");
            }
            else
            {
                Response.Write("<script>alert('Assisstant Does not Exist');</script>");

             //   Response.Redirect("Login.aspx");
            }
        }
    }
}