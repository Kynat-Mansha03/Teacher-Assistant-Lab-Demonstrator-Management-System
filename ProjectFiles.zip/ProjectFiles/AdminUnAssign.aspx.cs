﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
 //   int Fac_id;
  
    protected void Page_Load(object sender, EventArgs e)
    {
       

        //Label2.Visible = false;
        //TextBox2.Visible = false;
        //Button1.Visible = false;
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminHireTA.aspx");
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminHireLD.aspx");
    }

    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminUnAssign.aspx");
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
      var Fac_id = Convert.ToInt32(TextBox1.Text);
        var Appl_id = Convert.ToInt32(TextBox2.Text);
        int count = 0;
        string querycount = "Select count(*) from hire group by Appl_id having Appl_id="+Appl_id;
        SqlCommand cmdCount=new SqlCommand(querycount, conn);
        SqlDataReader readcount=cmdCount.ExecuteReader();
        if (readcount.Read())
        {
            count = Convert.ToInt32(readcount[0]);
        }
        readcount.Close();
        //   if (TA == 1)
        int TA = 0, LD = 0;
        if (DropDownList1.SelectedValue == "Lab Demonstrator")
            LD = 1;
        else
            TA = 1;
        if (LD == 1)
        {
            string query7 = "Select* from hire where Appl_ID =" + Appl_id + " AND Fac_ID =" + Fac_id + "and LD=" + 1;
            SqlCommand cmd = new SqlCommand(query7, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                reader.Close();
                string query1 = "DELETE FROM Hire WHERE Appl_ID =" + Appl_id + " AND Fac_ID =" + Fac_id + "and LD=" + 1;
                SqlCommand cmd1 = new SqlCommand(query1, conn);
                var does = cmd1.ExecuteNonQuery();
                if (does > 0)
                {
                    string query3 = " ";
                    if (count < 2) 
                    {
                         query3 = "UPDATE Applicants SET Appl_hire_status = 0, Appl_LD = 0 WHERE Appl_ID =" + Appl_id;
                    }else
                    {
                          query3 = "UPDATE Applicants SET Appl_LD = 0 WHERE Appl_ID =" + Appl_id;
                    }
                    SqlCommand cmd3 = new SqlCommand(query3, conn);
                    cmd3.ExecuteNonQuery();
                    Response.Write("<script>alert('LD Deleted');</script>");
                }
                else
                {
                    Response.Write("<script>alert('LD Not Exist');</script>");
                }
            }
            else
                Response.Write("<script>alert('LD Not Exist');</script>");
        }
        else
        {
            string query7 = "Select* from hire where Appl_ID =" + Appl_id + " AND Fac_ID =" + Fac_id + "and TA=" + 1;
            SqlCommand cmd = new SqlCommand(query7, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                reader.Close();
                string query1 = "DELETE FROM Hire WHERE Appl_ID =" + Appl_id + " AND Fac_ID =" + Fac_id + "and TA=" + 1;
                SqlCommand cmd1 = new SqlCommand(query1, conn);
                var does = cmd1.ExecuteNonQuery();
                if (does > 0)
                {
                    string query2 = " ";
                    if (count < 2)
                    {
                        query2 = "UPDATE Applicants SET Appl_hire_status = 0, Appl_TA = 0 WHERE Appl_ID =" + Appl_id;
                    }
                    else
                    {
                        query2 = "UPDATE Applicants SET Appl_TA = 0 WHERE Appl_ID =" + Appl_id;
                    }
                     SqlCommand cmd2 = new SqlCommand(query2, conn);
                    cmd2.ExecuteNonQuery();
                    Response.Write("<script>alert('TA Deleted');</script>");
                }
                else
                {
                    Response.Write("<script>alert('TA Not Exist');</script>");
                }
            }
            else

                Response.Write("<script>alert('TA Not Exist');</script>");
        }

    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminTAReport.aspx");
    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminLDReport.aspx");
    }

    protected void GridView3_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    //void PopulateData(int Fac_id)
    //{
    //    SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
    //    conn.Open();
    //    string query;
    //    if (TA == 1)
    //        query = "SELECT A2.Appl_ID,A2.Appl_Name,A1.Grade,A1.COUR_ID,A1.SEC_ALP,A1.SEC_BATCH,A1.SEC_DEPT FROM Applicants A2 JOIN Apply_for A1 ON A2.Appl_ID=A1.Appl_ID JOIN Teaches_Course T1 ON A1.Cour_ID=T1.Cour_id AND A1.Sec_alp=T1.Sec_alp AND A1.Sec_Batch=T1.Sec_Batch AND A1.Sec_dept=T1.Sec_dept JOIN HIRE H1 ON H1.Fac_ID=T1.Fac_ID WHERE T1.Fac_ID=" + Fac_id;//+ "and H1.TA="+1;
    //    else
    //        query = "SELECT A2.Appl_ID,A2.Appl_Name,A1.Grade,A1.COUR_ID,A1.SEC_ALP,A1.SEC_BATCH,A1.SEC_DEPT FROM Applicants A2 JOIN Apply_for A1 ON A2.Appl_ID=A1.Appl_ID JOIN Teaches_Course T1 ON A1.Cour_ID=T1.Cour_id AND A1.Sec_alp=T1.Sec_alp AND A1.Sec_Batch=T1.Sec_Batch AND A1.Sec_dept=T1.Sec_dept JOIN HIRE H1 ON H1.Fac_ID=T1.Fac_ID WHERE T1.Fac_ID=" + Fac_id; //+ "and H1.LD=" + 1;

    //    SqlCommand cmd = new SqlCommand(query, conn);
    //    SqlDataReader reader = cmd.ExecuteReader();
    //    if (reader.Read())
    //    {
    //        GridView3.DataSource = reader;
    //        GridView3.DataBind();
    //    }
    //    else
    //    {
    //        Response.Write("<script>alert('No Assisstant Assigned');</script>");
    //    }

    //}

    //protected void Button2_Click(object sender, EventArgs e)
    //{
    //    
    //    Button2.Visible = false;
    //    PopulateData(Fac_id);
    //    //   GridView3.Visible = true;
    //    Label2.Visible = true;
    //    TextBox2.Visible = true;
    //    Button1.Visible = true;
    //}

    protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminPayment.aspx");
    }
}