﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    int Appl_id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        PopulateData1();
    }
    void PopulateData1()
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query = "SELECT A1.Appl_ID,A1.Appl_Name,Appl_Contact,A1.Appl_hire_status,A1.Appl_cgpa,A1.Appl_Email,A1.Appl_TA,A1.Appl_LD,A2.COUR_ID FROM APPLICANTS A1 JOIN Apply_for A2 ON A1.Appl_ID=A2.Appl_ID WHERE A1.Appl_ID IN(SELECT distinct Appl_ID FROM HIRE WHERE Fac_ID =" + Session["FACULTY_ID"] + ")";
        SqlCommand cmd = new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        //    if(reader.Read())
        //   {
        reader.Close();
        SqlDataAdapter d = new SqlDataAdapter(cmd);
        DataTable dataTable = new DataTable();
        d.Fill(dataTable);
        GridView1.DataSource = dataTable;
        GridView1.DataBind();

        //  }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Appl_id = Convert.ToInt32(TextBox1.Text);
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query = "select * from hire where fac_id=" + Session["Faculty_ID"] + "and Appl_id=" + Appl_id;
       SqlCommand cmd= new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        if(reader.Read())
        {
            Session["FEED"] = Appl_id;
            Response.Redirect("FacultyFeedback(3).aspx");
            reader.Close();
        }
         else
        {
            Response.Write("<script>alert('Applicant Not Assigned to Faculty');</script>");
            reader.Close();
        }
    }


    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyAssignTA.aspx");
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyAssignLD.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyReportTA.aspx");
    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyReportLD.aspx");
    }

    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Faculty_feed.aspx");
    }
}