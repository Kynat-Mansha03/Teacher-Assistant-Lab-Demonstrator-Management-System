﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminLDReport_2_ : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        PopulateData();
    }

    void PopulateData() 
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        //    string query = "SELECT A1.Appl_ID,A1.Appl_Name,Appl_Contact,A1.Appl_hire_status,A1.Appl_cgpa,A1.Appl_Email,A1.Appl_TA,A1.Appl_LD,A2.COUR_ID FROM APPLICANTS A1 JOIN Apply_for A2 ON A1.Appl_ID=A2.Appl_ID WHERE A1.Appl_TA=1 AND A1.Appl_ID IN(SELECT Appl_ID FROM HIRE WHERE Fac_ID =" + Session["FACULTY_ID"] + " and TA=1)";
        string query = "SELECT  F.Fac_Name,  F.Fac_id ,  F.Fac_contact ,  F.Fac_Email ,  TC.Cour_id ,  TC.Sec_dept ,  TC.Sec_Batch ,  TC.Sec_alp ,  TC.Start_time,  TC.End_time FROM    Applicants A JOIN  Hire H ON A.Appl_ID = H.Appl_ID and H.LD=1 JOIN  Teaches_Course TC ON H.Fac_ID = TC.Fac_ID JOIN  Apply_for AF ON A.Appl_ID = AF.Appl_ID AND TC.Cour_id = AF.Cour_ID AND TC.Sec_alp=AF.Sec_alp AND TC.Sec_Batch=AF.Sec_Batch AND TC.Sec_dept = AF.Sec_dept JOIN FACULTY F ON F.Fac_id=TC.Fac_ID WHERE  A.Appl_ID =" + Session["LDReport"];
        SqlCommand cmd = new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        //    if(reader.Read())
        //   {
        GridView1.DataSource = reader;
        GridView1.DataBind();
    }
    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminHireLD.aspx");
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminHireTA.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminTAReport.aspx");
    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminLDReport.aspx");
    }

    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminUnAssign.aspx");
    }

    protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminPayment.aspx");
    }
}