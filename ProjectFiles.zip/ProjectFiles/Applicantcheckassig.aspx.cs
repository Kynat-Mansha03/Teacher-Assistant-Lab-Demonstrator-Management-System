﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Applicantcheckassig : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        PopulateGridView2();
    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    void PopulateGridView2()
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query = "SELECT F.Fac_Name,F.Fac_id ,F.Fac_contact , F.Fac_Email ,TC.Cour_id ,TC.Sec_dept ,TC.Sec_Batch ,TC.Sec_alp ,TC.Start_time,TC.End_time FROM Applicants A JOIN Hire H ON A.Appl_ID = H.Appl_ID  JOIN Teaches_Course TC ON H.Fac_ID = TC.Fac_ID JOIN Apply_for AF ON A.Appl_ID = AF.Appl_ID AND TC.Cour_id = AF.Cour_ID AND TC.Sec_alp=AF.Sec_alp AND TC.Sec_Batch=AF.Sec_Batch AND TC.Sec_dept = AF.Sec_dept JOIN FACULTY F ON F.Fac_id=TC.Fac_ID WHERE A.Appl_ID ="+ Session["APPLICANT_ID"];
        SqlCommand cmd = new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        //     if (reader.Read())
        //    {
        GridView2.DataSource = reader;
        GridView2.DataBind();

        //     }
    }
    void PopulateGridView1()
    {
        var Fac_id = Convert.ToInt32(TextBox1.Text);
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        //string query1 = "SELECT A1.Assig_id,A1.Assig_Title,A1.Complete_Status,A1.Due_time,A1.Due_Date,A1.Cour_id FROM Assignment A1 JOIN Assigns A2 ON A1.Assig_ID=A2.Assig_ID AND A2.Appl_ID=" + Session["APPLICANT_ID"] + " AND A2.Fac_ID=" + Fac_id;
        //SqlCommand cmd1= new SqlCommand(query1, conn);
        //SqlDataReader reader1 = cmd1.ExecuteReader();
        //if (reader1.Read())
        //{
          
            string query = "SELECT A1.Assig_id,A1.Assig_Title,A1.Complete_Status,A1.Due_time,A1.Due_Date,A1.Cour_id FROM Assignment A1 JOIN Assigns A2 ON A1.Assig_ID=A2.Assig_ID AND A2.Appl_ID=" + Session["APPLICANT_ID"] + " AND A2.Fac_ID=" + Fac_id + " AND A1.Complete_Status =0";
            SqlCommand cmd = new SqlCommand(query, conn);
         //   reader1.Close();
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                GridView1.DataSource = reader;
                GridView1.DataBind();
            }
            else
            {
                Response.Write("<script>alert('Completed All Assignments');</script>");
            }
            reader.Close();
     //   }
        //else
        //{
        //    reader1.Close();
        //    Response.Write("<script>alert('InValid Data');</script>");
        //}
    }

    void LoadEdited()
    {
        var Fac_id = Convert.ToInt32(TextBox1.Text);
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query1 = "SELECT A1.Assig_id,A1.Assig_Title,A1.Complete_Status,A1.Due_time,A1.Due_Date,A1.Cour_id FROM Assignment A1 JOIN Assigns A2 ON A1.Assig_ID=A2.Assig_ID AND A2.Appl_ID=" + Session["APPLICANT_ID"] + " AND A2.Fac_ID=" + Fac_id;
        SqlCommand cmd1= new SqlCommand(query1, conn);
        SqlDataReader reader1 = cmd1.ExecuteReader();
        if (reader1.Read())
        {
            reader1.Close();
            string query = "SELECT A1.Assig_id,A1.Assig_Title,A1.Complete_Status,A1.Due_time,A1.Due_Date,A1.Cour_id FROM Assignment A1 JOIN Assigns A2 ON A1.Assig_ID=A2.Assig_ID AND A2.Appl_ID=" + Session["APPLICANT_ID"] + " AND A2.Fac_ID=" + Fac_id + " AND A1.Complete_Status =0";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                reader.Close();
                SqlDataAdapter d = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                d.Fill(dataTable);
                GridView1.DataSource = dataTable;
                GridView1.DataBind();
            }
            else
            {
                reader.Close();
                Response.Write("<script>alert('Completed All Assignments');</script>");
            }
           
        }
        else
        {
            reader1.Close();
            Response.Write("<script>alert('InValid Data');</script>");
        }
    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Applicantcheckassig.aspx");
    }


    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ApplicantCheckedassig.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ApplicantFeed.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
       
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        int Assi_ID = 0;
        for(int i=0;i<GridView1.Rows.Count;i++)
        {
            CheckBox checkassig = (CheckBox)GridView1.Rows[i].FindControl("CheckBox1");
            if(checkassig.Checked == true)
            {
                Assi_ID = Convert.ToInt32(GridView1.Rows[i].Cells[1].Text);
                string query2 = "UPDATE Assignment SET Complete_Status = 1 WHERE Assig_ID =" + Assi_ID;
                SqlCommand cmd = new SqlCommand(query2, conn);
                var checking=cmd.ExecuteNonQuery();
                if(checking > 0 )
                {
                    string c_date=null,c_time=null, comp_date=null, comp_time=null;
                    //string query3 = "SELECT CONVERT(DATE, GETDATE()) ;";
                    //SqlCommand cmd3=new SqlCommand(query3, conn);   
                    //SqlDataReader reader3=cmd3.ExecuteReader();
                    //if(reader3.Read())
                    //{
                    //    c_date= reader3.GetString(0);
                    //    reader3.Close();
                    //}
                    //string query4 = "SELECT CONVERT(VARCHAR(8), GETDATE(),108)";
                    //SqlCommand cmd4 = new SqlCommand(query4, conn);
                    //SqlDataReader reader4 = cmd4.ExecuteReader();
                    //if (reader4.Read())
                    //{
                    //   c_time = reader4.GetString(0);
                    //    reader4.Close();
                    //}

                    DateTime currentDate = DateTime.Now;

                    // Format the current date and time to match the format of DUE_DATE and DUE_TIME
                     c_date = currentDate.ToString("yyyy-MM-dd");
                     c_time = currentDate.ToString("HH:mm:ss");
                    string query5 = "SELECT DUE_TIME,DUE_DATE FROM Assignment WHERE Assig_ID=" + Assi_ID;
                    SqlCommand cmd5 = new SqlCommand(query5, conn);
                    SqlDataReader reader5 = cmd5.ExecuteReader();
                    if (reader5.Read())
                    {
                        comp_date = reader5[1].ToString();
                        comp_time= reader5[0].ToString();
                        reader5.Close();
                    }
                    if ((string.Compare(c_date, comp_date) > 0) || (string.Compare(c_time, comp_time) > 0))
                    {
                        string query4 = "UPDATE Assignment SET Late = 1 WHERE Assig_ID =" + Assi_ID;
                        SqlCommand cmd4 = new SqlCommand(query4, conn);
                        cmd4.ExecuteNonQuery();
                        Response.Write("<script>alert('Submitted Late');</script>");
                    }
                    else
                    {
                        Response.Write("<script>alert('Submitted Successfully');</script>");
                    }
                }
                else
                {
                    Response.Write("<script>alert('Not Assigned');</script>");
                }
            }
        }
        LoadEdited();
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //  PopulateGridView1();
        LoadEdited();
    }
}