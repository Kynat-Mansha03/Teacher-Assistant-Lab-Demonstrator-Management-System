﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FacultyFeedBack_3_ : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyAssignTA.aspx");
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyAssignLD.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyReportTA.aspx");
    }


    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyReportLD.aspx");
    }

    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Faculty_feed.aspx");
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int Form_id = 0;
        string response = "";
        var Appl_ID = Session["FEED"];
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query1 = "INSERT INTO FEEDBACK (FAC_ID,APPL_ID) VALUES (@FACID,@APPLID);";
        using (SqlCommand cmd1 = new SqlCommand(query1, conn))
        {
            //   Command.Parameters.AddWithValue("@FORMID")
            cmd1.Parameters.AddWithValue("@FACID", Session["Faculty_ID"]);
            cmd1.Parameters.AddWithValue("@APPLID", Session["FEED"]);
            cmd1.ExecuteNonQuery();
        }
        string query2 = "Select Form_id from feedback where Fac_ID=" + Session["Faculty_ID"] + "and Appl_ID=" + Session["FEED"];
        SqlCommand cmd2 = new SqlCommand(query2, conn);
        SqlDataReader reader2 = cmd2.ExecuteReader();
        if (reader2.Read())
        {
            Form_id = Convert.ToInt32(reader2[0]);
            reader2.Close();
        }
        string[] questions = { "qs1", "qs2", "qs3", "qs4", "qs5" };
        string questionst = " ";
        foreach (string question in questions)
        {
            // foreach (Control control in form1.Controls)
            //{
            //   if (control is Label label && label.ID == $"Lbl{question}")
            //  {
            Label label = form1.FindControl($"Lbl{question}") as Label;
            questionst = label.Text;
            //         foreach (Control control1 in form1.Controls)
            //        {
            //           if (control1 is RadioButtonList radioButtonList && radioButtonList.ID == $"Rbl{question}")
            //          {
            RadioButtonList radioButtonList = form1.FindControl($"Rbl{question}") as RadioButtonList;
            response = radioButtonList.SelectedValue;
            //          }
            //     }
            //  }
            string query3 = "INSERT INTO Responses (FORM_ID,RESPONSE,QUESTION) VALUES (@FORMID,@RESP,@QUEST)";
            using (SqlCommand cmd3 = new SqlCommand(query3, conn))
            {
                cmd3.Parameters.AddWithValue("@FORMID", Form_id);
                cmd3.Parameters.AddWithValue("@RESP", response);
                cmd3.Parameters.AddWithValue("@QUEST", questionst);
                cmd3.ExecuteNonQuery();
            }
        }
        Response.Write("<script>alert('FeedBack Filled Successfully');</script>");
        //   string query1=""

        //   }
    }
//}
}