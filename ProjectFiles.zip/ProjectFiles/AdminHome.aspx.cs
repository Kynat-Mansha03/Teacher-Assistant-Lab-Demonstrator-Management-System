﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query = "Select * from Admin where Admin_ID =" + Session["Admin_ID"] + ";";
        SqlCommand cmd= new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        if(reader.Read())
        {
            Label1.Text = reader[0].ToString();
            Label2.Text = reader[1].ToString();
            Label3.Text = reader[3].ToString();
            Label4.Text = reader[4].ToString();
        }
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminHireTA.aspx");
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminHireLD.aspx");
    }

    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminUnAssign.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminTAReport.aspx");
    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminLDReport.aspx");
    }

    protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminPayment.aspx");
    }
}