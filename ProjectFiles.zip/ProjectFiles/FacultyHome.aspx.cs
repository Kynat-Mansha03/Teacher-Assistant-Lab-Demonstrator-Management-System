﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query = "Select * from Faculty where Fac_ID =" + Session["Faculty_ID"] + ";";
        SqlCommand cmd = new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.Read())
        {
           Label1.Text  = reader[0].ToString();
            Label2.Text = reader[1].ToString();
             Label3.Text= reader[3].ToString();
             Label4.Text= reader[4].ToString();
        }
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyAssignTA.aspx");
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyAssignLD.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyReportTA.aspx");
    }


    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyReportLD.aspx");
    }


    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Faculty_feed.aspx");
    }
}