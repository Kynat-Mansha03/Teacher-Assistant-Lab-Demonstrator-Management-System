﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminPayment_2_ : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Populate();
        pay();
    }
    void Populate()
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query = "SELECT A1.Appl_ID,A1.Appl_Name,A1.Appl_Contact,A1.Appl_Email,A2.Cour_ID,A2.Cour_ID,A2.Sec_dept,A2.Sec_Batch,A2.Sec_alp FROM APPLICANTS A1 JOIN APPLY_FOR A2 ON A1.Appl_ID=A2.Appl_ID  AND A1.Appl_ID=" + Session["PayID"]+ " and A1.Appl_hire_status =1";
          SqlCommand cmd = new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.Read())
        {
            reader.Close();
            SqlDataAdapter d = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable();
            d.Fill(dataTable);
            GridView1.DataSource = dataTable;
            GridView1.DataBind();
        }
         else
        {
            Response.Write("<script>alert('Applicant Not Hired');</script>");
        }
    }
    void pay()
    {
        int payment =0;
            int count = 0;
            SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
            conn.Open();
            string query1 = "SELECT COUNT(*) FROM HIRE WHERE APPL_ID=" + Session["PayID"];
            SqlCommand cmd1 = new SqlCommand(query1, conn);
            SqlDataReader reader1 = cmd1.ExecuteReader();
            if(reader1.Read())
            {
                count = Convert.ToInt32(reader1[0]);

            reader1.Close();

        }
        int TA = 0, LD = 0;
        string query2 = "SELECT Appl_TA FROM Applicants WHERE APPL_ID=" + Session["PayID"];
        SqlCommand cmd2 = new SqlCommand(query2, conn);
        SqlDataReader reader2 = cmd2.ExecuteReader();
        if (reader2.Read())
        {
            TA = Convert.ToInt32(reader2[0]);

            reader2.Close();

        }
        string query3 = "SELECT Appl_LD FROM Applicants WHERE APPL_ID=" + Session["PayID"];
        SqlCommand cmd3 = new SqlCommand(query3, conn);
        SqlDataReader reader3 = cmd3.ExecuteReader();
        if (reader3.Read())
        {
            LD = Convert.ToInt32(reader3[0]);

            reader3.Close();

        }
        if(TA==1 && LD==1)
            {
            payment = 30000;
        }
        else if(TA==1 && LD==0)
        {
            payment = count * 10000;
        }
        else if(TA==0 && LD==1) 
        {
            payment = count * 20000;
        }
        //    payment = count * payment;
           Label3.Text=payment.ToString();
        //}
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminHireTA.aspx");
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminHireLD.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminTAReport.aspx");
    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminLDReport.aspx");
    }

    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminUnAssign.aspx");
    }

    protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminPayment.aspx");
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}