﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //PopulateData();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        //var Fac_ID =
    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {
        //TA
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        var Fac_ID = Convert.ToInt32( TextBox1.Text);
        var TA_ID= Convert.ToInt32(TextBox2.Text);
     //   int convertedFac_ID = Convert.ToInt32(Fac_ID);
     //   int convertedTA_ID = Convert.ToInt32(TA_ID);
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string queryFAC = "Select * from Faculty where Fac_id=" + Fac_ID;
        string queryTA = "Select * from Applicants where Appl_ID=" + TA_ID;
        SqlCommand cmdFAC=new SqlCommand(queryFAC, conn);
        SqlDataReader readFAC= cmdFAC.ExecuteReader();
        if(readFAC.Read())
        {
            readFAC.Close();
        }
        else
        {
            Response.Write("<script>alert('Invalid Faculty ID');</script>");
            return;
        }
        SqlCommand cmdTA = new SqlCommand(queryTA, conn);
        SqlDataReader readTA = cmdTA.ExecuteReader();
        if (readTA.Read())
        {
            readTA.Close();
        }
        else
        {
            Response.Write("<script>alert('Invalid TA ID');</script>");
            return;
        }

        string querycheck = "Select * from hire where fac_Id=" + Fac_ID + "and Appl_id=" + TA_ID + "and TA=1";
        SqlCommand cmdcheck = new SqlCommand(querycheck, conn);
        SqlDataReader readcheck = cmdcheck.ExecuteReader();
        if (readcheck.Read())
        {
            readcheck.Close();
            Response.Write("<script>alert('TA Already Assigned to Faculty');</script>");
            return;
        }
        else
        {
            readcheck.Close();
           
        }

        string query1 = "Select count(*) as COUNT_T from hire group by Appl_id having Appl_id ="+TA_ID;
        SqlCommand cmd = new SqlCommand(query1, conn);
        SqlDataReader reader1 = cmd.ExecuteReader();
        if (reader1.Read())
        {
           
            //check count 
            var count = reader1.GetInt32(0);
            reader1.Close();
            if (count<=1)
            {
                string query2= "SELECT A1.Appl_ID from Apply_for A1, Teaches_Course T1 where A1.Cour_ID=T1.Cour_id and A1.Sec_alp=T1.Sec_alp and A1.Sec_Batch=T1.Sec_Batch and A1.Sec_dept=T1.Sec_dept and A1.Start_Time=T1.Start_time and A1.End_Time=T1.End_time and A1.Appl_ID="+TA_ID+"and T1.Fac_ID="+Fac_ID;
                SqlCommand cmd2 = new SqlCommand(query2, conn);
                SqlDataReader reader2 = cmd2.ExecuteReader();
                if(reader2.Read())
                {
                    reader2.Close();
                    //hires and update hire and ta status
                    string query5= "UPDATE Applicants SET Appl_hire_status = 1,   Appl_TA = 1 WHERE Appl_ID = "+TA_ID;
                    SqlCommand cmd5= new SqlCommand(query5, conn);
                    var done= cmd5.ExecuteNonQuery();
                    //insertion query 
                    string query4 = "INSERT INTO Hire (Admin_ID, Fac_ID,Appl_id, TA, LD) VALUES (@ADMIN_ID, @Fac_ID,@Appl_id, @TA_status, @LD_status);";

                    using (SqlCommand cmd4 = new SqlCommand(query4, conn))
                    {
                        cmd4.Parameters.AddWithValue("@ADMIN_ID", Session["ADMIN_ID"]);
                        cmd4.Parameters.AddWithValue("@Fac_ID", Fac_ID);
                        cmd4.Parameters.AddWithValue("@Appl_id", TA_ID);
                        cmd4.Parameters.AddWithValue("@TA_status", 1); // Assuming TA_status is intended for the TA column
                        cmd4.Parameters.AddWithValue("@LD_status", 0); // Assuming LD_status is intended for the LD column
                                                                       // Execute your command here
                        var numRowsEffected = cmd4.ExecuteNonQuery();
                        if (numRowsEffected > 0)
                        {
                            Response.Write("<script>alert('Hired Successfully');</script>");
                        }
                    }
                }
                else
                {
                    Response.Write("<script>alert('Cannot Assign');</script>");
                }
               // reader2.Close();
            }
            else
            {
                Response.Write("<script>alert('Cannot Assign');</script>");
            }
        }
        else
        {
            // TA is not in the hire table
            reader1.Close();
            string query3 = "SELECT A1.Appl_ID from Apply_for A1, Teaches_Course T1 where A1.Cour_ID=T1.Cour_id and A1.Sec_alp=T1.Sec_alp and A1.Sec_Batch=T1.Sec_Batch and A1.Sec_dept=T1.Sec_dept and A1.Start_Time=T1.Start_time and A1.End_Time=T1.End_time and A1.Appl_ID =" + TA_ID + "and T1.Fac_ID =" + Fac_ID+";";
            SqlCommand cmd5 = new SqlCommand(query3, conn);
            SqlDataReader reader3 = cmd5.ExecuteReader();
            if (reader3.Read())
            {
                reader3.Close();
                //hires 
                //int Admin_ID
                //   string query4 = "insert into Hire values(" + Session["ADMIN_ID"] + "," + Fac_ID + "," + TA_ID + ");";
                //hires and update hire and ta status
                string query5 = "UPDATE Applicants SET Appl_hire_status = 1,   Appl_TA = 1 WHERE Appl_ID = " + TA_ID;
                SqlCommand cmd6 = new SqlCommand(query5, conn);
                var done = cmd6.ExecuteNonQuery();
                //insertion query 
                string query4 = "INSERT INTO Hire (Admin_ID, Fac_ID,Appl_id, TA, LD) VALUES (@ADMIN_ID, @Fac_ID,@Appl_id, @TA_status, @LD_status);";

                using (SqlCommand cmd4 = new SqlCommand(query4, conn))
                {
                    cmd4.Parameters.AddWithValue("@ADMIN_ID", Session["ADMIN_ID"]);
                    cmd4.Parameters.AddWithValue("@Fac_ID", Fac_ID);
                    cmd4.Parameters.AddWithValue("@Appl_id", TA_ID);
                    cmd4.Parameters.AddWithValue("@TA_status", 1); // Assuming TA_status is intended for the TA column
                    cmd4.Parameters.AddWithValue("@LD_status", 0); // Assuming LD_status is intended for the LD column
                                                                   // Execute your command here
                    var numRowsEffected = cmd4.ExecuteNonQuery();
                    if (numRowsEffected > 0)
                    {
                        Response.Write("<script>alert('Hired Successfully');</script>");
                    }
                }
                //  SqlCommand cmd4 = new SqlCommand(query4, conn);

            }
            else
            {
                Response.Write("<script>alert('Cannot Assign');</script>");
            }
        }
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminHireLD.aspx");
    }

    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminUnAssign.aspx");
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminHireTA.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminTAReport.aspx");
    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminLDReport.aspx");
    }

    protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AdminPayment.aspx");
    }
}