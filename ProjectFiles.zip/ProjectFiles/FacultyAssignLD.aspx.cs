﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        PopulateData1();
        PopulateData2();
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        var APPL_ID = Convert.ToInt32(TextBox1.Text);
        var ASSI_ID = Convert.ToInt32(TextBox2.Text);
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();


        /// check if appl_id and Assi_id id valid 
        string queryappl = "Select * from hire where fac_id=" + Session["FACULTY_ID"] + "and appl_id=" + APPL_ID + "and LD=1";
        SqlCommand cmdappl = new SqlCommand(queryappl, conn);
        SqlDataReader readappl = cmdappl.ExecuteReader();
        if (readappl.Read())
        {
            readappl.Close();
        }
        else
        {
            Response.Write("<script>alert('InValid Assisstant');</script>");
            return;
        }

        string queryassi = "Select * from Assignment where assig_id=" + ASSI_ID;
        SqlCommand cmdassi = new SqlCommand(queryassi, conn);
        SqlDataReader readassi = cmdassi.ExecuteReader();
        if (readassi.Read())
        {
            readassi.Close();
        }
        else
        {
            Response.Write("<script>alert('InValid Assignment');</script>");
            return;
        }


        /////actual implementation

        string query = "Select * from Assigns where Assig_ID=" + ASSI_ID + "and FAC_ID = " + Session["FACULTY_ID"] + "and Appl_ID =" + APPL_ID;
        SqlCommand cmd = new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        if (reader.Read())
        {
            Response.Write("<script>alert('Assignment Already Assigned');</script>");
            reader.Close();
        }
        else
        {
            reader.Close();
            string query1 = "SELECT A1.COUR_ID,A1.SEC_ALP,A1.SEC_BATCH,A1.SEC_DEPT FROM Apply_for A1 JOIN Teaches_Course T1 ON A1.Cour_ID=T1.Cour_id AND A1.Sec_alp=T1.Sec_alp AND A1.Sec_Batch=T1.Sec_Batch AND A1.Sec_dept=T1.Sec_dept WHERE A1.Appl_ID=" + APPL_ID + "AND T1.Fac_ID=" + Session["FACULTY_ID"];
            SqlCommand cmd1 = new SqlCommand(query1, conn);
            SqlDataReader reader1 = cmd1.ExecuteReader();
            if (reader1.Read())
            {

                var COUR_ID = reader1.GetInt32(0);
                var SEC_ALP = reader1[1].ToString();
                var SEC_BATCH = reader1[2].ToString();
                var SEC_DEPT = reader1[3].ToString();
                reader1.Close();
                string query2 = "Select Cour_id from assignment where assig_id=" + ASSI_ID + "and complete_status=0";
                SqlCommand cmd2 = new SqlCommand(query2, conn);
                SqlDataReader reader2 = cmd2.ExecuteReader();
                if (reader2.Read())
                {
                    var COUR_ID_Ass = reader2.GetInt32(0);
                    reader2.Close();
                    if (COUR_ID_Ass == COUR_ID)
                    {
                        var Fac_ID = Session["FACULTY_ID"];
                        string query3 = "SELECT ASSIG_TITLE FROM ASSIGNMENT WHERE ASSIG_ID = " + ASSI_ID + " AND COUR_ID IN (SELECT COUR_ID FROM LEARNS_COURSE WHERE COUR_ID = " + COUR_ID_Ass + " AND SEC_DEPT = '" + SEC_DEPT + "' AND SEC_ALP = '" + SEC_ALP + "' AND SEC_BATCH = '" + SEC_BATCH + "');";
                        SqlCommand cmd3 = new SqlCommand(query3, conn);
                        SqlDataReader reader3 = cmd3.ExecuteReader();
                        if (reader3.Read())
                        {
                            reader3.Close();
                            string query4 = "INSERT INTO Assigns VALUES (@ASSI_ID, @Fac_ID, @APPL_ID);";
                            using (SqlCommand cmd4 = new SqlCommand(query4, conn))
                            {
                                cmd4.Parameters.AddWithValue("@ASSI_ID", ASSI_ID);
                                cmd4.Parameters.AddWithValue("@Fac_ID", Fac_ID);
                                cmd4.Parameters.AddWithValue("@APPL_ID", APPL_ID);


                                var numRowsEffected = cmd4.ExecuteNonQuery();
                                if (numRowsEffected > 0)
                                {
                                    Response.Write("<script>alert('Assigned Successfully');</script>");
                                }
                            }
                        }
                        else
                        {
                            Response.Write("<script>alert('LD not assigned to Section');</script>");
                        }
                    }
                    else
                    {
                        Response.Write("<script>alert('LD not assigned to Course');</script>");
                    }
                }
                else
                {
                    Response.Write("<script>alert('Assignment Status Complete');</script>");
                }
            }
        }
    }

    void PopulateData1()
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query = "SELECT A1.Appl_ID,A1.Appl_Name,Appl_Contact,A1.Appl_hire_status,A1.Appl_cgpa,A1.Appl_Email,A1.Appl_TA,A1.Appl_LD,A2.COUR_ID FROM APPLICANTS A1 JOIN Apply_for A2 ON A1.Appl_ID=A2.Appl_ID WHERE A1.Appl_LD=1 AND A1.Appl_ID IN(SELECT Appl_ID FROM HIRE WHERE Fac_ID =" + Session["FACULTY_ID"] + " and LD=1)";
        SqlCommand cmd = new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        //    if(reader.Read())
        //   {
        GridView1.DataSource = reader;
        GridView1.DataBind();

        //  }
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    void PopulateData2()
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query = "SELECT A1.Assig_id,A1.Assig_Title,A1.Complete_Status,A1.Due_time,A1.Due_Date,A1.Cour_id FROM Assignment A1 JOIN COURSE C1 ON A1.Cour_ID=C1.C_id JOIN Teaches_Course T1 ON T1.Cour_id=C1.C_id WHERE T1.Fac_ID=" + Session["FACULTY_ID"];
        SqlCommand cmd = new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        //     if (reader.Read())
        //    {
        GridView2.DataSource = reader;
        GridView2.DataBind();

        //     }
    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyAssignTA.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyReportTA.aspx");
    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyReportLD.aspx");
    }

    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Faculty_feed.aspx");
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyAssignLD.aspx");
    }
}