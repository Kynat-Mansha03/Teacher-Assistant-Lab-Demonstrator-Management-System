﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ApplicantCheckedassig : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        PopulateGridView1();
    }
    void PopulateGridView1()
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query = "SELECT F.Fac_Name,F.Fac_id ,F.Fac_contact , F.Fac_Email ,TC.Cour_id ,TC.Sec_dept ,TC.Sec_Batch ,TC.Sec_alp ,TC.Start_time,TC.End_time FROM Applicants A JOIN Hire H ON A.Appl_ID = H.Appl_ID  JOIN Teaches_Course TC ON H.Fac_ID = TC.Fac_ID JOIN Apply_for AF ON A.Appl_ID = AF.Appl_ID AND TC.Cour_id = AF.Cour_ID AND TC.Sec_alp=AF.Sec_alp AND TC.Sec_Batch=AF.Sec_Batch AND TC.Sec_dept = AF.Sec_dept JOIN FACULTY F ON F.Fac_id=TC.Fac_ID WHERE A.Appl_ID =" + Session["APPLICANT_ID"];
        SqlCommand cmd = new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        //     if (reader.Read())
        //    {
        GridView1.DataSource = reader;
        GridView1.DataBind();

        //     }
    }
    
        void PopulateGridView2()
        {
            var Fac_id = Convert.ToInt32(TextBox1.Text);
            SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
            conn.Open();
        string query1 = "SELECT A1.Assig_id,A1.Assig_Title,A1.Complete_Status,A1.Due_time,A1.Due_Date,A1.Cour_id FROM Assignment A1 JOIN Assigns A2 ON A1.Assig_ID=A2.Assig_ID AND A2.Appl_ID=" + Session["APPLICANT_ID"] + " AND A2.Fac_ID=" + Fac_id;
        SqlCommand cmd1= new SqlCommand(query1, conn);
        SqlDataReader reader1 = cmd1.ExecuteReader();
        if (reader1.Read())
        {
            reader1.Close();
            string query = "SELECT A1.Assig_id,A1.Assig_Title,A1.Complete_Status,A1.Due_time,A1.Due_Date,A1.Cour_id FROM Assignment A1 JOIN Assigns A2 ON A1.Assig_ID=A2.Assig_ID AND A2.Appl_ID=" + Session["APPLICANT_ID"] + " AND A2.Fac_ID=" + Fac_id + " AND A1.Complete_Status =1";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            //     if (reader.Read())
            //    {
            GridView2.DataSource = reader;
            GridView2.DataBind();
        }
        else
        {
            Response.Write("<script>alert('InValid Data');</script>");

        }
    }

    
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        PopulateGridView2();
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        int Assi_ID = 0;
        for (int i = 0; i < GridView2.Rows.Count; i++)
        {

            Label lblLateStatus = (Label)GridView2.Rows[i].FindControl("Label3");
            Assi_ID = Convert.ToInt32(GridView2.Rows[i].Cells[1].Text);
            // bool isLate= Convert.ToBoolean(GridView2.Rows[i].Cells[1].Text);
            //string query3 = "SELECT CONVERT(DATE, GETDATE()) ;";
            //SqlCommand cmd3=new SqlCommand(query3, conn);   
            //SqlDataReader reader3=cmd3.ExecuteReader();
            //if(reader3.Read())
            //{
            //    c_date= reader3.GetString(0);
            //    reader3.Close();
            //}
            // Set the text based on the condition
            bool isLate = false;
            string query3 = "SELECT Late from Assignment where Assig_ID=" + Assi_ID;
            SqlCommand cmd3 = new SqlCommand(query3, conn);
            SqlDataReader reader3 = cmd3.ExecuteReader();
            if (reader3.Read())
            {
                isLate = Convert.ToBoolean(reader3[0]);
            }
            if (isLate)
            {
                lblLateStatus.Text = "Late";
                lblLateStatus.ForeColor = System.Drawing.Color.Red;

            }
            else
            {
                lblLateStatus.Text = "On Time";
                lblLateStatus.ForeColor = System.Drawing.Color.Green;

            }
            reader3.Close();
        }
     //   GridView2.DataBind();
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Applicantcheckassig.aspx");
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ApplicantCheckedassig.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ApplicantFeed.aspx");
    }
}