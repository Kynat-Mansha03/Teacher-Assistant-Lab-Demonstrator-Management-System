﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ApplicantFeed : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        PopulateData();
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    void PopulateData()
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query = " SELECT  R1.* FROM Responses R1 JOIN FeedBack F1 ON R1.Form_ID=F1.Form_ID AND F1.Appl_ID=" + Session["APPLICANT_ID"];
         SqlCommand cmd = new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
        //     if (reader.Read())
        //    {
        GridView1.DataSource = reader;
        GridView1.DataBind();
    }
}