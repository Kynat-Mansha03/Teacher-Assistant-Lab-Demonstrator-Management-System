﻿using System;
using System.Activities.Expressions;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        PopulateData();
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyAssignTA.aspx");
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyAssignLD.aspx");
    }

    protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyReportTA.aspx");
    }

    protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("FacultyReportLD.aspx");
    }

    protected void ImageButton5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Faculty_feed.aspx");
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    void PopulateData()
    {
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-V30SSAGT\\SQLEXPRESS;Initial Catalog=\"TA/LD Management System\";Integrated Security=True");
        conn.Open();
        string query = "SELECT  A.Appl_ID, A.Appl_Name AS LDName,A.Appl_Contact,A.Appl_Email,AC.Assig_ID, ASG.Assig_Title,ASG.Complete_Status,ASG.Late FROM Faculty F JOIN Assigns AC ON F.Fac_ID = AC.Fac_ID JOIN Assignment ASG ON AC.Assig_ID = ASG.Assig_ID JOIN Applicants A ON AC.Appl_ID = A.Appl_ID WHERE A.Appl_LD = 1 AND A.APPL_ID IN (SELECT DISTINCT APPL_ID FROM HIRE WHERE Fac_ID=" + Session["Faculty_ID"] + "and LD=1)";
        SqlCommand cmd = new SqlCommand(query, conn);
        SqlDataReader reader = cmd.ExecuteReader();
       // if (reader.Read())
        //{
            GridView1.DataSource = reader;
            GridView1.DataBind();
        //}
        //else
        //{
         //   Response.Write("<script>alert('InValid Data');</script>");

        //}

    }
}